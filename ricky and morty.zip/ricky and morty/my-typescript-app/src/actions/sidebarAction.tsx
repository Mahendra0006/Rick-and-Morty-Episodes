import { Episode } from "../services/EpisodeService";

export type Action =
  | { type: "FETCH_INIT" }
  | { type: "FETCH_SUCCESS"; payload: Episode[] }
  | { type: "FETCH_FAILURE"; payload: Error };


export const fetchInit = (): Action => ({ type: "FETCH_INIT" });

export const fetchSuccess = (episodes: Episode[]): Action => ({
  type: "FETCH_SUCCESS",
  payload: episodes,
});

export const fetchFailure = (error: Error): Action => ({
  type: "FETCH_FAILURE",
  payload: error,
});
