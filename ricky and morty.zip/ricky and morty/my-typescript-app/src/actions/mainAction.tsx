import { Episode } from "../services/EpisodeService";


export type Action =
  | { type: "SET_LOADING"; payload: boolean }
  | { type: "FETCH_CHARACTERS_SUCCESS"; payload: { characters: Episode[]; totalPages: number } }
  | { type: "SET_CURRENT_PAGE"; payload: number };

export const setLoading = (loading: boolean): Action => ({
  type: "SET_LOADING",
  payload: loading,
});

export const fetchCharactersSuccess = (characters: Episode[], totalPages: number): Action => ({
  type: "FETCH_CHARACTERS_SUCCESS",
  payload: { characters, totalPages },
});

export const setCurrentPage = (page: number): Action => ({
  type: "SET_CURRENT_PAGE",
  payload: page,
});
