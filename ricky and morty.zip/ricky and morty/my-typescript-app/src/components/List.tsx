// src/components/List.tsx

import React, { useEffect, useReducer, useCallback } from "react";
import { useParams } from "react-router-dom";
import Sidebar from "../common/Sidebar";
import Loader from "../common/Loader";
import EpisodeService from "../services/EpisodeService";
import { initialState, reducer } from "../reducres/listReducer"; 
import { setLoading, fetchEpisodeSuccess, fetchCharactersSuccess, Episode, Character } from '../actions/listActions'; 

const List: React.FC = () => {
  const { episodeId } = useParams<{ episodeId: string }>();
  const [state, dispatch] = useReducer(reducer, initialState);
  const { episode, characters, loading } = state;

  const fetchEpisodeAndCharacters = useCallback(async () => {
    dispatch(setLoading(true));
    try {
      if (episodeId) {
        const episodeData = await EpisodeService.GetEpisodes(parseInt(episodeId));
        if (episodeData) {
          dispatch(fetchEpisodeSuccess(episodeData));

          const characterPromises = episodeData.characters.map((url: string) =>
            fetch(url).then((res) => res.json())
          );
          const characterData = await Promise.all(characterPromises);
          dispatch(fetchCharactersSuccess(characterData));
        }
      }
    } catch (error) {
      console.error("Error fetching episode and characters:", error);
    } finally {
      dispatch(setLoading(false));
    }
  }, [episodeId]);

  useEffect(() => {
    fetchEpisodeAndCharacters();
  }, [episodeId, fetchEpisodeAndCharacters]);

  if (loading) return <Loader />;

  return (
    <div className="container">
      <h2 className="" style={{ textAlign: "center" }}>
        Rick and Morty Characters in Episode {episodeId}
      </h2>
      <div className="row" style={{ display: "flex" }}>
        <div className="col-md-3">
          <Sidebar />
        </div>
        <div className="col-md-9">
          <h4 className="character-heading">
            {characters.length} Characters in episode {episodeId}
          </h4>
          <div className="character-grid">
            {characters.map((character) => (
              <div className="character" key={character?.id}>
                <img alt={character?.name} src={character?.image} />
                <p style={{ marginTop: "10px" }}>{character?.name}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default List;
