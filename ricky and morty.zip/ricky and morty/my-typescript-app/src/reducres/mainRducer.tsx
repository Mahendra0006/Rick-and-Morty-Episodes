import { Action } from '../actions/mainAction';
import { Episode } from "../services/EpisodeService";


export interface State {
  currentPage: number;
  characters: Episode[];
  totalPages: number;
  loading: boolean;
}

export const initialState: State = {
  currentPage: 1,
  characters: [],
  totalPages: 0,
  loading: false,
};

export const reducer = (state: State, action: Action): State => {
  switch (action.type) {
    case "SET_LOADING":
      return { ...state, loading: action.payload };
    case "FETCH_CHARACTERS_SUCCESS":
      return {
        ...state,
        loading: false,
        characters: action.payload.characters,
        totalPages: action.payload.totalPages,
      };
    case "SET_CURRENT_PAGE":
      return { ...state, currentPage: action.payload };
    default:
      return state;
  }
};
