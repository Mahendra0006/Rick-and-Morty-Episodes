import { Action, Episode, Character } from '../actions/listActions';


export interface State {
  episode: Episode | null;
  characters: Character[];
  loading: boolean;
}

export const initialState: State = {
  episode: null,
  characters: [],
  loading: false,
};

export const reducer = (state: State, action: Action): State => {
  switch (action.type) {
    case "SET_LOADING":
      return { ...state, loading: action.payload };
    case "FETCH_EPISODE_SUCCESS":
      return { ...state, episode: action.payload };
    case "FETCH_CHARACTERS_SUCCESS":
      return { ...state, characters: action.payload };
    default:
      return state;
  }
};
