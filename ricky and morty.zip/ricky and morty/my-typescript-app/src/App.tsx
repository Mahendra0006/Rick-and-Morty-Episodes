import React from "react";
import { Routes, Route } from "react-router-dom";
import Main from "./components/Main"; 
import List from "./components/List"; 
import "./App.css";

const App: React.FC = () => {
  return (
    <Routes>
      <Route path="/" element={<Main />} />
      <Route path="/episode/:episodeId" element={<List />} />
    </Routes>
  );
};

export default App;
