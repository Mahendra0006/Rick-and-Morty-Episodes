import requests from "./Service"; 

// Define and export the Character interface
export interface Character {
  id: number;
  name: string;
  image: string;
}

// Define and export the Episode interface
export interface Episode {
  id: number;
  name: string;
  air_date: string;
  episode: string;
  characters: string[]; 
  image: string; 
}

export interface EpisodeInfo {
  count: number; 
  pages: number; 
  next: string | null; 
  prev: string | null; 
}


export interface EpisodeResponse {
  info: EpisodeInfo;
  results: Episode[]; 
}

const EpisodeService = {
  GetEpisode: async (body: string): Promise<any> => {
    return requests.get(`/episode?${body}`); 
  },
  GetEpisodes: async (id: number): Promise<any> => {
    return requests.get(`/episode/${id}`); 
  },
  GetLocation: async (body: string): Promise<any> => { 
    return requests.get(`/location?${body}`);
  },
  GetCharacters: async (body: string): Promise<any> => { 
    return requests.get(`/character?${body}`);
  },
};

export default EpisodeService;
