import React from "react";

// Define the prop types interface
interface PaginationProps {
  currentPage: number;
  totalPages: number;
  onPageChange: (page: number) => void;
}

const Pagination: React.FC<PaginationProps> = ({ currentPage, totalPages, onPageChange }) => {
  const pages = Array.from({ length: totalPages }, (_, i) => i + 1);

  return (
    <div className="pagination-container">
    {pages.map((page) => (
      <button
        key={page}
        className={`pagination-button ${page === currentPage ? 'active' : ''}`}
        onClick={() => onPageChange(page)}
      >
        {page}
      </button>
    ))}
  </div>
  );
};

export default Pagination;
